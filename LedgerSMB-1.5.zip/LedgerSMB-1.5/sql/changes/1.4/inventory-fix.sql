
ALTER TABLE inventory RENAME TO warehouse_inventory;
