
UPDATE language SET code = 'ms_MY' WHERE code = 'my';
