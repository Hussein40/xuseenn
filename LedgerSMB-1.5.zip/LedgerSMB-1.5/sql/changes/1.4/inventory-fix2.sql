
ALTER SEQUENCE inventory_entry_id_seq
   RENAME TO warehouse_inventory_entry_id_seq;
