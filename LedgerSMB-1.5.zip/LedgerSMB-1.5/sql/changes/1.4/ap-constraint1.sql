
ALTER TABLE ap ADD COLUMN is_return bool default false;
