

UPDATE menu_attribute
   SET attribute = 'template_name'
 WHERE node_id IN (29, 30, 31, 32, 33)
   AND attribute = 'name';

