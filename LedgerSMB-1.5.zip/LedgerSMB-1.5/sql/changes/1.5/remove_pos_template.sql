DELETE FROM menu_acl WHERE node_id IN (188, 189);
DELETE FROM menu_attribute WHERE node_id IN (188, 189);
DELETE FROM menu_node WHERE id IN (188, 189);
